cmd_scripts/mod/modpost := gcc   -o scripts/mod/modpost scripts/mod/modpost.o scripts/mod/file2alias.o scripts/mod/sumversion.o -L/home/user/openwrt-master/staging_dir/host/lib 
